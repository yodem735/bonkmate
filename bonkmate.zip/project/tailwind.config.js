/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'bonk-orange': '#FF8C00',
        'bonk-brown': '#D2691E',
        'bonk-bat': '#8B4513',
        'bonk-light': '#FFB84D',
        'bonk-dark': '#CC7000',
      },
      fontFamily: {
        'bonk': ['Comic Sans MS', 'cursive'],
        'bonk-bold': ['Impact', 'Arial Black', 'sans-serif'],
      },
      animation: {
        'bounce-slow': 'bounce 2s infinite',
        'wiggle': 'wiggle 1s ease-in-out infinite',
        'bonk': 'bonk 0.5s ease-in-out',
      },
      keyframes: {
        wiggle: {
          '0%, 100%': { transform: 'rotate(-3deg)' },
          '50%': { transform: 'rotate(3deg)' },
        },
        bonk: {
          '0%': { transform: 'scale(1)' },
          '50%': { transform: 'scale(1.2) rotate(5deg)' },
          '100%': { transform: 'scale(1)' },
        }
      }
    },
  },
  plugins: [],
};