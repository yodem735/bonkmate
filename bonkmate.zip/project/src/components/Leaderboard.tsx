import React from 'react';
import { Trophy, TrendingUp, DollarSign, Crown, Medal, Award, Star, Zap } from 'lucide-react';
import { Player } from '../types/chess';

interface LeaderboardProps {
  players: Player[];
}

const Leaderboard: React.FC<LeaderboardProps> = ({ players }) => {
  const sortedByRating = [...players].sort((a, b) => b.rating - a.rating);
  const sortedByEarnings = [...players].sort((a, b) => b.totalEarnings - a.totalEarnings);
  const sortedByBonk = [...players].sort((a, b) => b.bonkTokens - a.bonkTokens);

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <span className="text-3xl">🏆</span>;
      case 2:
        return <span className="text-3xl">🥈</span>;
      case 3:
        return <span className="text-3xl">🥉</span>;
      default:
        return <span className="bonk-title text-bonk-orange font-bold">#{rank}</span>;
    }
  };

  const LeaderboardTable = ({ title, players, sortKey, icon, emoji }: {
    title: string;
    players: Player[];
    sortKey: 'rating' | 'totalEarnings' | 'bonkTokens';
    icon: React.ReactNode;
    emoji: string;
  }) => (
    <div className="bg-white rounded-2xl border-4 border-black p-6 bonk-glow">
      <div className="flex items-center mb-6">
        <span className="text-4xl mr-3">{emoji}</span>
        <h3 className="bonk-title text-2xl text-bonk-orange">{title}</h3>
      </div>
      
      <div className="space-y-3">
        {players.slice(0, 10).map((player, index) => {
          const rank = index + 1;
          const winRate = player.wins + player.losses > 0 
            ? ((player.wins / (player.wins + player.losses)) * 100).toFixed(1)
            : '0.0';
          
          return (
            <div
              key={player.id}
              className={`
                flex items-center justify-between p-4 rounded-xl transition-all duration-200 border-2 border-black
                ${rank <= 3 
                  ? 'bg-gradient-to-r from-bonk-orange to-bonk-brown text-white bonk-glow' 
                  : 'bg-bonk-light hover:bg-bonk-orange hover:text-white'
                }
              `}
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 flex justify-center">
                  {getRankIcon(rank)}
                </div>
                <div className="text-4xl">🦊</div>
                <div>
                  <div className="bonk-title text-lg font-bold">{player.username}</div>
                  <div className="text-sm opacity-80">
                    {player.address 
                      ? `${player.address.slice(0, 6)}...${player.address.slice(-4)}`
                      : player.email 
                      ? `${player.email.slice(0, 6)}...${player.email.slice(-4)}`
                      : 'Unknown'
                    }
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-6 text-right">
                <div>
                  <div className="bonk-title text-xl font-bold">
                    {sortKey === 'rating' 
                      ? player.rating 
                      : sortKey === 'totalEarnings'
                      ? `${player.totalEarnings.toFixed(1)} SOL`
                      : `${player.bonkTokens} BONK`
                    }
                  </div>
                  <div className="text-sm opacity-80">
                    {sortKey === 'rating' ? 'Rating' : sortKey === 'totalEarnings' ? 'Earnings' : 'BONK Tokens'}
                  </div>
                </div>
                <div>
                  <div className="text-sm font-semibold">
                    {player.wins}W-{player.losses}L-{player.draws}D
                  </div>
                  <div className="text-xs opacity-80">
                    {winRate}% Win Rate
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );

  return (
    <div className="space-y-8">
      {/* Hero Header */}
      <div className="text-center py-8 bg-gradient-to-r from-bonk-orange via-bonk-brown to-bonk-orange rounded-2xl border-4 border-black bonk-glow">
        <div className="float-animation mb-4">
          <span className="text-8xl">🏆</span>
        </div>
        <h1 className="bonk-title text-5xl text-white bonk-shadow mb-2">
          BONK CHAMPIONS!
        </h1>
        <p className="text-xl text-black font-bold">
          The greatest BONK warriors of all time! 🦊
        </p>
      </div>

      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-yellow-400 to-orange-500 p-6 rounded-2xl border-4 border-black bonk-glow">
          <div className="flex items-center justify-between">
            <div>
              <div className="bonk-title text-3xl text-white bonk-shadow">
                {sortedByRating[0]?.rating || 0}
              </div>
              <div className="text-sm text-black font-bold">Highest Rating</div>
            </div>
            <span className="text-5xl">👑</span>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-green-400 to-emerald-500 p-6 rounded-2xl border-4 border-black bonk-glow">
          <div className="flex items-center justify-between">
            <div>
              <div className="bonk-title text-3xl text-white bonk-shadow">
                {sortedByEarnings[0]?.totalEarnings.toFixed(1) || '0.0'} SOL
              </div>
              <div className="text-sm text-black font-bold">Top Earnings</div>
            </div>
            <span className="text-5xl">💰</span>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-purple-400 to-pink-500 p-6 rounded-2xl border-4 border-black bonk-glow">
          <div className="flex items-center justify-between">
            <div>
              <div className="bonk-title text-3xl text-white bonk-shadow">{players.length}</div>
              <div className="text-sm text-black font-bold">Total Bonkers</div>
            </div>
            <span className="text-5xl">🦊</span>
          </div>
        </div>
      </div>

      {/* Leaderboard Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <LeaderboardTable
          title="Top Rated Bonkers"
          players={sortedByRating}
          sortKey="rating"
          icon={<TrendingUp className="text-bonk-orange" size={24} />}
          emoji="⭐"
        />
        
        <LeaderboardTable
          title="Richest Bonkers"
          players={sortedByEarnings}
          sortKey="totalEarnings"
          icon={<DollarSign className="text-green-400" size={24} />}
          emoji="💰"
        />
      </div>

      {/* BONK Token Leaderboard */}
      <LeaderboardTable
        title="BONK Token Champions"
        players={sortedByBonk}
        sortKey="bonkTokens"
        icon={<Zap className="text-bonk-orange" size={24} />}
        emoji="🪙"
      />
    </div>
  );
};

export default Leaderboard;