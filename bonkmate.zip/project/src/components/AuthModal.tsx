import React, { useState } from 'react';
import { X, Mail, Lock, User, Wallet, Loader2 } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const [mode, setMode] = useState<'login' | 'register' | 'wallet'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const { login, register, connectWallet } = useAuth();

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      let success = false;
      
      if (mode === 'login') {
        success = await login(email, password);
      } else if (mode === 'register') {
        success = await register(email, password, username);
      } else if (mode === 'wallet') {
        success = await connectWallet();
      }

      if (success) {
        onClose();
        setEmail('');
        setPassword('');
        setUsername('');
      } else {
        setError('Authentication failed. Please try again.');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleWalletConnect = async () => {
    setIsLoading(true);
    setError('');
    
    try {
      const success = await connectWallet();
      if (success) {
        onClose();
      } else {
        setError('Wallet connection failed. Please try again.');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl border-4 border-black max-w-md w-full bonk-glow">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="bonk-title text-2xl text-bonk-orange">
              {mode === 'wallet' ? 'Connect Wallet' : mode === 'login' ? 'Welcome Back!' : 'Join BONK Chess!'}
            </h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-bonk-light rounded-full transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          {/* Mode Selector */}
          <div className="flex space-x-2 mb-6">
            <button
              onClick={() => setMode('login')}
              className={`flex-1 py-2 px-4 rounded-xl font-bold border-2 border-black transition-all ${
                mode === 'login'
                  ? 'bg-bonk-orange text-white'
                  : 'bg-white text-bonk-orange hover:bg-bonk-light'
              }`}
            >
              Login
            </button>
            <button
              onClick={() => setMode('register')}
              className={`flex-1 py-2 px-4 rounded-xl font-bold border-2 border-black transition-all ${
                mode === 'register'
                  ? 'bg-bonk-orange text-white'
                  : 'bg-white text-bonk-orange hover:bg-bonk-light'
              }`}
            >
              Register
            </button>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-100 border-2 border-red-500 rounded-xl">
              <p className="text-red-700 font-semibold text-sm">{error}</p>
            </div>
          )}

          {/* Wallet Connection */}
          <div className="mb-6">
            <button
              onClick={handleWalletConnect}
              disabled={isLoading}
              className="w-full flex items-center justify-center space-x-3 p-4 bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white rounded-xl font-bold border-3 border-black bonk-glow hover:scale-105 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <Loader2 className="animate-spin" size={20} />
              ) : (
                <Wallet size={20} />
              )}
              <span className="bonk-title">
                {isLoading ? 'Connecting...' : 'Connect Solana Wallet 🚀'}
              </span>
            </button>
            <p className="text-xs text-bonk-brown text-center mt-2 font-semibold">
              Wallet required for wagering features
            </p>
          </div>

          <div className="flex items-center mb-6">
            <div className="flex-1 h-px bg-bonk-brown"></div>
            <span className="px-4 text-bonk-brown font-bold">OR</span>
            <div className="flex-1 h-px bg-bonk-brown"></div>
          </div>

          {/* Email Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <div>
                <label className="block text-sm font-bold text-bonk-orange mb-2">
                  Username
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-bonk-brown" size={18} />
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border-3 border-black rounded-xl focus:outline-none focus:ring-2 focus:ring-bonk-orange font-semibold"
                    placeholder="Choose a username"
                    required
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-sm font-bold text-bonk-orange mb-2">
                Email
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-bonk-brown" size={18} />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border-3 border-black rounded-xl focus:outline-none focus:ring-2 focus:ring-bonk-orange font-semibold"
                  placeholder="your@email.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-bonk-orange mb-2">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-bonk-brown" size={18} />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border-3 border-black rounded-xl focus:outline-none focus:ring-2 focus:ring-bonk-orange font-semibold"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex items-center justify-center space-x-2 p-4 bg-gradient-to-r from-bonk-orange to-bonk-brown hover:from-bonk-brown hover:to-bonk-orange text-white rounded-xl font-bold border-3 border-black bonk-glow hover:scale-105 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <Loader2 className="animate-spin" size={20} />
              ) : (
                <span className="text-2xl">🦊</span>
              )}
              <span className="bonk-title">
                {isLoading 
                  ? 'Processing...' 
                  : mode === 'login' 
                    ? 'Login to BONK!' 
                    : 'Join the BONK!'
                }
              </span>
            </button>
          </form>

          <div className="mt-6 p-4 bg-bonk-light/20 rounded-xl border-2 border-bonk-orange">
            <p className="text-xs text-bonk-brown font-semibold text-center">
              <span className="text-bonk-orange font-bold">📧 Email accounts:</span> Play for fun, no wagering<br/>
              <span className="text-bonk-orange font-bold">🔗 Wallet accounts:</span> Full features + SOL wagering
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;