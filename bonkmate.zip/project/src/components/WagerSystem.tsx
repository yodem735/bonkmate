import React, { useState } from 'react';
import { DollarSign, Users, Clock, Zap, TrendingUp, Star, Gamepad2, Lock, Mail, Wallet } from 'lucide-react';
import { GameRoom, Player } from '../types/chess';
import { useAuth } from '../contexts/AuthContext';

interface WagerSystemProps {
  onCreateGame: (wager: number) => void;
  onJoinGame: (gameId: string) => void;
  availableGames: GameRoom[];
  currentPlayer: Player;
}

const WagerSystem: React.FC<WagerSystemProps> = ({ 
  onCreateGame, 
  onJoinGame, 
  availableGames, 
  currentPlayer 
}) => {
  const [selectedWager, setSelectedWager] = useState(0.1);
  const [showCreateGame, setShowCreateGame] = useState(false);
  const { user, isAuthenticated } = useAuth();

  const wagerOptions = [0.1, 0.5, 1.0, 2.5, 5.0, 10.0];
  const canWager = user?.accountType === 'wallet';

  const handleCreateGame = (wager: number) => {
    if (!canWager && wager > 0) return;
    onCreateGame(wager);
    setShowCreateGame(false);
  };

  const handleJoinGame = (gameId: string) => {
    const game = availableGames.find(g => g.id === gameId);
    if (!game) return;
    
    if (game.requiresWallet && !canWager) return;
    onJoinGame(gameId);
  };

  if (!isAuthenticated || !user) {
    return (
      <div className="space-y-6">
        <div className="text-center py-12 bg-gradient-to-r from-bonk-orange via-bonk-brown to-bonk-orange rounded-2xl border-4 border-black bonk-glow">
          <div className="text-8xl mb-4">🔒</div>
          <h1 className="bonk-title text-4xl text-white bonk-shadow mb-4">
            Login Required!
          </h1>
          <p className="text-xl text-black font-bold mb-6">
            Create an account to start playing BONK Chess!
          </p>
          <div className="text-lg text-white font-semibold">
            📧 Email: Play for fun • 🔗 Wallet: Play for SOL!
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Hero Section */}
      <div className="text-center py-8 bg-gradient-to-r from-bonk-orange via-bonk-brown to-bonk-orange rounded-2xl border-4 border-black bonk-glow">
        <div className="float-animation mb-4">
          <span className="text-8xl">🦊</span>
          <span className="text-6xl animate-wiggle inline-block ml-2">🏏</span>
        </div>
        <h1 className="bonk-title text-5xl text-white bonk-shadow mb-2">
          READY TO BONK?
        </h1>
        <p className="text-xl text-black font-bold">
          {canWager ? 'Challenge players and win SOL! 💰' : 'Play for fun and glory! 🏆'}
        </p>
      </div>

      {/* Account Type Notice */}
      {!canWager && (
        <div className="bg-gradient-to-r from-blue-100 to-purple-100 p-6 rounded-2xl border-4 border-blue-500">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="text-4xl">📧</div>
              <div>
                <h3 className="bonk-title text-xl text-blue-700">Email Account</h3>
                <p className="text-blue-600 font-semibold">Playing for fun - no wagering available</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-blue-600 font-semibold mb-2">Want to wager SOL?</div>
              <div className="flex items-center text-purple-600 font-bold">
                <Wallet size={16} className="mr-1" />
                Connect Wallet in Profile
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Player Stats */}
      <div className="bg-white p-6 rounded-2xl border-4 border-black bonk-glow">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <div className="text-6xl">{user.avatar}</div>
            <div>
              <h2 className="bonk-title text-3xl text-bonk-orange">{user.username}</h2>
              <div className="flex items-center space-x-2">
                {user.accountType === 'wallet' ? (
                  <>
                    <Wallet size={16} className="text-purple-600" />
                    <p className="text-bonk-brown font-bold">{user.address?.slice(0, 8)}...{user.address?.slice(-6)}</p>
                  </>
                ) : (
                  <>
                    <Mail size={16} className="text-blue-600" />
                    <p className="text-bonk-brown font-bold">{user.email}</p>
                  </>
                )}
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="bonk-title text-4xl text-bonk-orange">{user.rating}</div>
            <div className="text-sm text-bonk-brown font-bold">BONK RATING</div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="bg-gradient-to-br from-green-400 to-green-500 p-4 rounded-xl border-3 border-black text-center">
            <div className="text-2xl mb-1">🏆</div>
            <div className="bonk-title text-2xl text-white bonk-shadow">{user.wins}</div>
            <div className="text-xs text-black font-bold">WINS</div>
          </div>
          <div className="bg-gradient-to-br from-red-400 to-red-500 p-4 rounded-xl border-3 border-black text-center">
            <div className="text-2xl mb-1">💥</div>
            <div className="bonk-title text-2xl text-white bonk-shadow">{user.losses}</div>
            <div className="text-xs text-black font-bold">BONKS</div>
          </div>
          <div className="bg-gradient-to-br from-yellow-400 to-yellow-500 p-4 rounded-xl border-3 border-black text-center">
            <div className="text-2xl mb-1">🤝</div>
            <div className="bonk-title text-2xl text-white bonk-shadow">{user.draws}</div>
            <div className="text-xs text-black font-bold">DRAWS</div>
          </div>
          <div className="bg-gradient-to-br from-purple-400 to-purple-500 p-4 rounded-xl border-3 border-black text-center">
            <div className="text-2xl mb-1">💰</div>
            <div className="bonk-title text-2xl text-white bonk-shadow">{user.totalEarnings.toFixed(1)}</div>
            <div className="text-xs text-black font-bold">SOL WON</div>
          </div>
          <div className="bg-gradient-to-br from-bonk-orange to-bonk-brown p-4 rounded-xl border-3 border-black text-center">
            <div className="text-2xl mb-1">🪙</div>
            <div className="bonk-title text-2xl text-white bonk-shadow">{user.bonkTokens}</div>
            <div className="text-xs text-black font-bold">BONK</div>
          </div>
        </div>
      </div>

      {/* Create Game Section */}
      <div className="bg-white p-6 rounded-2xl border-4 border-black">
        <button
          onClick={() => setShowCreateGame(!showCreateGame)}
          className="w-full flex items-center justify-center p-6 bg-gradient-to-r from-bonk-orange to-bonk-brown hover:from-bonk-brown hover:to-bonk-orange rounded-xl transition-all duration-200 text-white font-bold border-3 border-black bonk-glow hover:scale-105"
        >
          <Gamepad2 className="mr-3" size={24} />
          <span className="bonk-title text-2xl">CREATE BONK BATTLE!</span>
          <span className="ml-3 text-3xl animate-wiggle">🏏</span>
        </button>

        {showCreateGame && (
          <div className="mt-6 space-y-4">
            <div>
              <label className="block bonk-title text-xl text-bonk-orange mb-4">
                Choose Your {canWager ? 'Wager (SOL)' : 'Game Type'} 💰
              </label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {canWager ? (
                  wagerOptions.map((wager) => (
                    <button
                      key={wager}
                      onClick={() => setSelectedWager(wager)}
                      className={`p-4 rounded-xl border-3 border-black transition-all duration-200 font-bold ${
                        selectedWager === wager
                          ? 'bg-bonk-orange text-white bonk-glow transform scale-105'
                          : 'bg-white text-bonk-orange hover:bg-bonk-light hover:scale-105'
                      }`}
                    >
                      <div className="text-2xl mb-1">💰</div>
                      <div className="bonk-title">{wager} SOL</div>
                    </button>
                  ))
                ) : (
                  <button
                    onClick={() => setSelectedWager(0)}
                    className={`p-4 rounded-xl border-3 border-black transition-all duration-200 font-bold ${
                      selectedWager === 0
                        ? 'bg-bonk-orange text-white bonk-glow transform scale-105'
                        : 'bg-white text-bonk-orange hover:bg-bonk-light hover:scale-105'
                    }`}
                  >
                    <div className="text-2xl mb-1">🏆</div>
                    <div className="bonk-title">Fun Game</div>
                  </button>
                )}
              </div>
            </div>
            
            <button
              onClick={() => handleCreateGame(selectedWager)}
              className="w-full p-4 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 rounded-xl transition-all duration-200 text-white font-bold border-3 border-black bonk-glow hover:scale-105"
            >
              <span className="bonk-title text-xl">
                START BONK BATTLE {canWager && selectedWager > 0 ? `FOR ${selectedWager} SOL` : 'FOR FUN'}! 🚀
              </span>
            </button>
          </div>
        )}
      </div>

      {/* Available Games */}
      <div className="bg-white p-6 rounded-2xl border-4 border-black">
        <h3 className="bonk-title text-2xl text-bonk-orange mb-6 flex items-center">
          <Users className="mr-3" size={24} />
          BONK BATTLES WAITING! 🎯
        </h3>
        
        {availableGames.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-8xl mb-4">😴</div>
            <p className="bonk-title text-xl text-bonk-brown mb-2">No battles yet!</p>
            <p className="text-bonk-brown font-semibold">Create the first BONK battle!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {availableGames.map((game) => {
              const canJoin = !game.requiresWallet || canWager;
              
              return (
                <div
                  key={game.id}
                  className={`flex items-center justify-between p-4 rounded-xl border-3 border-black transition-all duration-200 ${
                    canJoin 
                      ? 'bg-gradient-to-r from-bonk-light to-white hover:bonk-glow' 
                      : 'bg-gray-100 opacity-60'
                  }`}
                >
                  <div className="flex items-center space-x-4">
                    <div className="text-4xl">{game.whitePlayer.avatar}</div>
                    <div>
                      <div className="bonk-title text-xl text-bonk-orange">{game.whitePlayer.username}</div>
                      <div className="text-sm text-bonk-brown font-semibold flex items-center space-x-2">
                        <Star size={12} />
                        <span>{game.whitePlayer.rating} rating</span>
                        {game.requiresWallet && (
                          <>
                            <Wallet size={12} className="text-purple-600" />
                            <span className="text-purple-600">Wallet Required</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-6">
                    <div className="text-center">
                      <div className="bonk-title text-2xl text-bonk-orange">
                        {game.wager > 0 ? `${game.wager} SOL` : 'Fun'}
                      </div>
                      <div className="text-xs text-bonk-brown font-bold">
                        {game.wager > 0 ? 'PRIZE' : 'GAME'}
                      </div>
                    </div>
                    
                    {canJoin ? (
                      <button
                        onClick={() => handleJoinGame(game.id)}
                        className="px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 rounded-xl transition-all duration-200 text-white font-bold border-3 border-black bonk-glow hover:scale-105"
                      >
                        <span className="bonk-title">BONK! 🏏</span>
                      </button>
                    ) : (
                      <div className="px-6 py-3 bg-gray-400 rounded-xl text-white font-bold border-3 border-black flex items-center space-x-2">
                        <Lock size={16} />
                        <span className="bonk-title text-sm">WALLET NEEDED</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default WagerSystem;