import React, { useState } from 'react';
import { Zap, Trophy, DollarSign, User, Crown, Gamepad2, LogIn } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import AuthModal from './AuthModal';
import ProfileModal from './ProfileModal';

interface HeaderProps {
  currentView: 'game' | 'wager' | 'leaderboard';
  onViewChange: (view: 'game' | 'wager' | 'leaderboard') => void;
}

const Header: React.FC<HeaderProps> = ({ currentView, onViewChange }) => {
  const { isAuthenticated, user } = useAuth();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);

  return (
    <>
      <header className="bg-gradient-to-r from-bonk-orange via-bonk-brown to-bonk-orange border-b-4 border-black shadow-xl sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <div className="flex items-center space-x-4">
              <div className="relative float-animation">
                <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center border-4 border-black bonk-glow">
                  <span className="text-3xl">🦊</span>
                </div>
                <div className="absolute -top-2 -right-2 animate-wiggle">
                  <span className="text-2xl">🏏</span>
                </div>
              </div>
              <div>
                <h1 className="bonk-title text-3xl font-bold text-white bonk-shadow">
                  BONK CHESS
                </h1>
                <p className="text-sm text-black font-bold">Solana's Funniest Chess Battle!</p>
              </div>
            </div>

            {/* Navigation */}
            <nav className="flex items-center space-x-2">
              <NavButton
                icon={<Gamepad2 size={20} />}
                label="PLAY!"
                isActive={currentView === 'game'}
                onClick={() => onViewChange('game')}
              />
              <NavButton
                icon={<DollarSign size={20} />}
                label="WAGER"
                isActive={currentView === 'wager'}
                onClick={() => onViewChange('wager')}
              />
              <NavButton
                icon={<Trophy size={20} />}
                label="BONK BOARD"
                isActive={currentView === 'leaderboard'}
                onClick={() => onViewChange('leaderboard')}
              />
            </nav>

            {/* User Profile */}
            <div className="flex items-center space-x-3">
              {isAuthenticated && user ? (
                <>
                  <div className="text-right">
                    <div className="text-sm font-bold text-white bonk-shadow">{user.username}</div>
                    <div className="flex items-center space-x-1 text-xs text-black font-semibold">
                      <span className={`w-2 h-2 rounded-full ${user.isConnected ? 'bg-green-400' : 'bg-red-400'}`}></span>
                      <span>{user.accountType === 'wallet' ? 'Wallet' : 'Email'}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowProfileModal(true)}
                    className="w-12 h-12 bg-gradient-to-br from-white to-bonk-light rounded-full flex items-center justify-center border-3 border-black bonk-glow hover:scale-110 transition-transform"
                  >
                    <span className="text-xl">{user.avatar}</span>
                  </button>
                </>
              ) : (
                <button
                  onClick={() => setShowAuthModal(true)}
                  className="flex items-center space-x-2 px-6 py-3 bg-white text-bonk-orange rounded-full font-bold border-3 border-black bonk-glow hover:scale-105 transition-all"
                >
                  <LogIn size={20} />
                  <span className="bonk-title">LOGIN</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
      <ProfileModal isOpen={showProfileModal} onClose={() => setShowProfileModal(false)} />
    </>
  );
};

const NavButton: React.FC<{
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => (
  <button
    onClick={onClick}
    className={`
      flex items-center space-x-2 px-6 py-3 rounded-full transition-all duration-200 font-bold border-3 border-black
      ${isActive
        ? 'bg-white text-bonk-orange bonk-glow transform scale-105'
        : 'bg-bonk-brown text-white hover:bg-white hover:text-bonk-orange hover:scale-105'
      }
    `}
  >
    {icon}
    <span className="bonk-title text-sm">{label}</span>
  </button>
);

export default Header;