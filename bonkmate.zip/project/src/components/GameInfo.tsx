import React from 'react';
import { GameState, Player } from '../types/chess';
import { Clock, Trophy, DollarSign, Zap, Star, AlertTriangle, Crown } from 'lucide-react';

interface GameInfoProps {
  gameState: GameState;
  whitePlayer: Player;
  blackPlayer: Player;
  wager: number;
  timeLeft: { white: number; black: number };
}

const GameInfo: React.FC<GameInfoProps> = ({ 
  gameState, 
  whitePlayer, 
  blackPlayer, 
  wager, 
  timeLeft 
}) => {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getGameStatusDisplay = () => {
    switch (gameState.gameStatus) {
      case 'check':
        return {
          text: `${gameState.currentPlayer === 'white' ? 'Fox' : 'Wolf'} in CHECK!`,
          icon: '⚠️',
          color: 'text-red-500'
        };
      case 'checkmate':
        const winner = gameState.currentPlayer === 'white' ? 'Wolf' : 'Fox';
        return {
          text: `CHECKMATE! ${winner} WINS!`,
          icon: '👑',
          color: 'text-yellow-500'
        };
      case 'stalemate':
        return {
          text: 'STALEMATE - DRAW!',
          icon: '🤝',
          color: 'text-blue-500'
        };
      case 'draw':
        return {
          text: 'DRAW GAME!',
          icon: '🤝',
          color: 'text-blue-500'
        };
      default:
        return {
          text: `${gameState.currentPlayer === 'white' ? 'Fox' : 'Wolf'} to BONK!`,
          icon: '⚡',
          color: 'text-bonk-orange'
        };
    }
  };

  const PlayerCard = ({ player, color, isActive, time }: { 
    player: Player; 
    color: 'white' | 'black'; 
    isActive: boolean;
    time: number;
  }) => (
    <div className={`
      p-4 rounded-xl border-3 border-black transition-all duration-300 bg-white
      ${isActive 
        ? 'bonk-glow transform scale-105 pulse-orange' 
        : 'hover:scale-102'
      }
    `}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-3">
          <div className="text-3xl">
            {color === 'white' ? '🦊' : '🐺'}
          </div>
          <div>
            <h3 className="font-bold text-bonk-orange bonk-title">{player.username}</h3>
            <p className="text-sm text-bonk-brown font-semibold">
              {player.address ? 
                `${player.address.slice(0, 6)}...${player.address.slice(-4)}` :
                player.email?.slice(0, 15) + '...'
              }
            </p>
          </div>
        </div>
        <div className="text-right">
          <div className="flex items-center text-bonk-orange font-bold">
            <Star size={16} className="mr-1" />
            {player.rating}
          </div>
          <div className="text-xs text-bonk-brown font-semibold">
            {player.bonkTokens} BONK
          </div>
        </div>
      </div>
      
      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center text-bonk-brown font-bold">
          <Clock size={14} className="mr-1" />
          <span className={time < 60 ? 'text-red-500 animate-pulse' : ''}>{formatTime(time)}</span>
        </div>
        <div className="text-bonk-brown font-semibold">
          {player.wins}W-{player.losses}L-{player.draws}D
        </div>
      </div>
    </div>
  );

  const statusInfo = getGameStatusDisplay();

  return (
    <div className="space-y-4">
      {/* Prize Pool */}
      <div className="text-center p-6 bg-gradient-to-r from-bonk-orange to-bonk-brown rounded-xl border-3 border-black bonk-glow">
        <div className="flex items-center justify-center mb-2">
          <span className="text-4xl mr-2">{wager > 0 ? '💰' : '🏆'}</span>
          <span className="bonk-title text-2xl font-bold text-white bonk-shadow">
            {wager > 0 ? `${wager} SOL` : 'FOR GLORY'}
          </span>
        </div>
        <div className="text-sm text-black font-bold">
          {wager > 0 ? 'BONK PRIZE POOL!' : 'BONK BATTLE!'}
        </div>
        <div className="mt-2 text-xs text-white font-semibold">
          {wager > 0 ? 'Winner takes all! 🏆' : 'Play for fun and rating! ⭐'}
        </div>
      </div>

      {/* Players */}
      <div className="space-y-3">
        <PlayerCard 
          player={blackPlayer} 
          color="black" 
          isActive={gameState.currentPlayer === 'black'}
          time={timeLeft.black}
        />
        <PlayerCard 
          player={whitePlayer} 
          color="white" 
          isActive={gameState.currentPlayer === 'white'}
          time={timeLeft.white}
        />
      </div>

      {/* Game Status */}
      <div className="p-4 rounded-xl bg-white border-3 border-black">
        <div className="flex items-center justify-center">
          <span className="text-2xl mr-2">{statusInfo.icon}</span>
          <span className={`bonk-title font-bold ${statusInfo.color}`}>
            {statusInfo.text}
          </span>
        </div>
        
        {/* Additional game state info */}
        {gameState.gameStatus === 'active' && gameState.fiftyMoveRule > 40 && (
          <div className="mt-2 text-center">
            <div className="text-xs text-orange-600 font-semibold">
              ⏰ {50 - gameState.fiftyMoveRule} moves until draw
            </div>
          </div>
        )}
      </div>

      {/* Move History */}
      <div className="p-4 rounded-xl bg-white border-3 border-black">
        <h4 className="bonk-title text-bonk-orange font-bold mb-3 flex items-center">
          <span className="mr-2">📜</span>
          BONK HISTORY
        </h4>
        <div className="max-h-32 overflow-y-auto text-sm space-y-1">
          {gameState.moveHistory.length === 0 ? (
            <div className="text-bonk-brown font-semibold text-center py-2">
              No bonks yet! Make the first move! 🏏
            </div>
          ) : (
            gameState.moveHistory.slice(-8).map((move, index) => (
              <div key={index} className="flex justify-between items-center bg-bonk-light/20 p-2 rounded">
                <span className="font-bold text-bonk-brown">{Math.floor(index / 2) + 1}.</span>
                <span className="font-semibold text-bonk-orange">{move}</span>
                <span className="text-xs">💥</span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Advanced Game Info */}
      <div className="grid grid-cols-2 gap-2">
        <div className="bg-white p-3 rounded-xl border-3 border-black text-center">
          <div className="text-2xl mb-1">🔥</div>
          <div className="text-xs font-bold text-bonk-orange">MOVE COUNT</div>
          <div className="font-bold text-bonk-brown">{gameState.moveHistory.length}</div>
        </div>
        <div className="bg-white p-3 rounded-xl border-3 border-black text-center">
          <div className="text-2xl mb-1">⚡</div>
          <div className="text-xs font-bold text-bonk-orange">CAPTURES</div>
          <div className="font-bold text-bonk-brown">
            {gameState.capturedPieces.white.length + gameState.capturedPieces.black.length}
          </div>
        </div>
      </div>

      {/* Castling Rights Indicator */}
      {(gameState.castlingRights.whiteKingSide || gameState.castlingRights.whiteQueenSide || 
        gameState.castlingRights.blackKingSide || gameState.castlingRights.blackQueenSide) && (
        <div className="bg-white p-3 rounded-xl border-3 border-black">
          <h5 className="text-xs font-bold text-bonk-orange mb-2">🏰 CASTLING AVAILABLE</h5>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <div className="font-semibold text-bonk-brown">🦊 Fox:</div>
              <div className="text-bonk-brown">
                {gameState.castlingRights.whiteKingSide && '♔ King-side '}
                {gameState.castlingRights.whiteQueenSide && '♕ Queen-side'}
                {!gameState.castlingRights.whiteKingSide && !gameState.castlingRights.whiteQueenSide && 'None'}
              </div>
            </div>
            <div>
              <div className="font-semibold text-bonk-brown">🐺 Wolf:</div>
              <div className="text-bonk-brown">
                {gameState.castlingRights.blackKingSide && '♚ King-side '}
                {gameState.castlingRights.blackQueenSide && '♛ Queen-side'}
                {!gameState.castlingRights.blackKingSide && !gameState.castlingRights.blackQueenSide && 'None'}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GameInfo;