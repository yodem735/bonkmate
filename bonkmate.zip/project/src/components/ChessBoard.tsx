import React, { useState, useCallback } from 'react';
import { ChessPiece, Position, GameState } from '../types/chess';
import ChessPieceComponent from './ChessPiece';

interface ChessBoardProps {
  gameState: GameState;
  onMove: (from: Position, to: Position) => void;
  onPieceSelect: (position: Position | null) => void;
}

const ChessBoard: React.FC<ChessBoardProps> = ({ gameState, onMove, onPieceSelect }) => {
  const [draggedPiece, setDraggedPiece] = useState<Position | null>(null);
  const [bonkAnimation, setBonkAnimation] = useState<Position | null>(null);

  const handleSquareClick = useCallback((x: number, y: number) => {
    const position = { x, y };
    const piece = gameState.board[y][x];

    if (gameState.selectedPiece) {
      if (gameState.selectedPiece.x === x && gameState.selectedPiece.y === y) {
        onPieceSelect(null);
      } else if (gameState.validMoves.some(move => move.x === x && move.y === y)) {
        // Trigger bonk animation
        setBonkAnimation(position);
        setTimeout(() => setBonkAnimation(null), 500);
        
        onMove(gameState.selectedPiece, position);
        onPieceSelect(null);
      } else if (piece && piece.color === gameState.currentPlayer) {
        onPieceSelect(position);
      } else {
        onPieceSelect(null);
      }
    } else if (piece && piece.color === gameState.currentPlayer) {
      onPieceSelect(position);
    }
  }, [gameState.selectedPiece, gameState.validMoves, gameState.currentPlayer, onMove, onPieceSelect]);

  const handleDragStart = useCallback((position: Position) => {
    const piece = gameState.board[position.y][position.x];
    if (piece && piece.color === gameState.currentPlayer) {
      setDraggedPiece(position);
      onPieceSelect(position);
    }
  }, [gameState.board, gameState.currentPlayer, onPieceSelect]);

  const handleDragEnd = useCallback((to: Position) => {
    if (draggedPiece && gameState.validMoves.some(move => move.x === to.x && move.y === to.y)) {
      setBonkAnimation(to);
      setTimeout(() => setBonkAnimation(null), 500);
      onMove(draggedPiece, to);
    }
    setDraggedPiece(null);
    onPieceSelect(null);
  }, [draggedPiece, gameState.validMoves, onMove, onPieceSelect]);

  const isSquareHighlighted = (x: number, y: number) => {
    return gameState.selectedPiece?.x === x && gameState.selectedPiece?.y === y;
  };

  const isValidMoveSquare = (x: number, y: number) => {
    return gameState.validMoves.some(move => move.x === x && move.y === y);
  };

  const isBonkAnimating = (x: number, y: number) => {
    return bonkAnimation?.x === x && bonkAnimation?.y === y;
  };

  return (
    <div className="relative">
      {/* Fun Header */}
      <div className="text-center mb-6">
        <h2 className="bonk-title text-4xl text-bonk-orange bonk-shadow mb-2">
          BONK BATTLE ARENA! 🏏
        </h2>
        <div className="flex items-center justify-center space-x-4">
          <div className="bg-white px-4 py-2 rounded-full border-3 border-black">
            <span className="font-bold text-bonk-orange">
              {gameState.currentPlayer === 'white' ? '🦊 Fox' : '🐺 Wolf'} Turn!
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-8 gap-0 border-4 border-black rounded-2xl overflow-hidden shadow-2xl bonk-glow bg-bonk-bat">
        {Array.from({ length: 8 }, (_, y) =>
          Array.from({ length: 8 }, (_, x) => {
            const isLight = (x + y) % 2 === 0;
            const piece = gameState.board[y][x];
            const isHighlighted = isSquareHighlighted(x, y);
            const isValidMove = isValidMoveSquare(x, y);
            const isBonking = isBonkAnimating(x, y);
            
            return (
              <div
                key={`${x}-${y}`}
                className={`
                  w-16 h-16 flex items-center justify-center relative cursor-pointer transition-all duration-300 border border-bonk-bat
                  ${isLight 
                    ? 'bg-gradient-to-br from-white to-bonk-light' 
                    : 'bg-gradient-to-br from-bonk-brown to-bonk-dark'
                  }
                  ${isHighlighted ? 'ring-4 ring-bonk-orange ring-opacity-80 pulse-orange' : ''}
                  ${isValidMove ? 'bg-gradient-to-br from-green-400 to-green-500 animate-pulse' : ''}
                  ${isBonking ? 'animate-bonk' : ''}
                  hover:brightness-110 hover:scale-105
                `}
                onClick={() => handleSquareClick(x, y)}
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => handleDragEnd({ x, y })}
              >
                {isValidMove && !piece && (
                  <div className="w-6 h-6 bg-green-500 rounded-full opacity-80 animate-bounce border-2 border-white">
                    <span className="text-xs">💥</span>
                  </div>
                )}
                {isValidMove && piece && (
                  <div className="absolute inset-0 border-4 border-red-500 rounded-lg opacity-80 animate-pulse">
                    <div className="absolute top-1 right-1 text-xs">💥</div>
                  </div>
                )}
                {piece && (
                  <ChessPieceComponent
                    piece={piece}
                    position={{ x, y }}
                    onDragStart={() => handleDragStart({ x, y })}
                    isDragging={draggedPiece?.x === x && draggedPiece?.y === y}
                  />
                )}
              </div>
            );
          })
        )}
      </div>
      
      {/* Coordinate labels with BONK style */}
      <div className="absolute -left-8 top-0 h-full flex flex-col justify-around text-lg font-bold text-bonk-orange bonk-shadow">
        {['8', '7', '6', '5', '4', '3', '2', '1'].map((num, i) => (
          <div key={num} className="flex items-center justify-center h-16">
            {num}
          </div>
        ))}
      </div>
      <div className="absolute -bottom-8 left-0 w-full flex justify-around text-lg font-bold text-bonk-orange bonk-shadow">
        {['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'].map((letter) => (
          <div key={letter} className="flex items-center justify-center w-16">
            {letter}
          </div>
        ))}
      </div>

      {/* Captured Pieces Display */}
      <div className="mt-6 grid grid-cols-2 gap-4">
        <div className="bg-white p-3 rounded-xl border-3 border-black">
          <h4 className="font-bold text-bonk-orange mb-2">🦊 Fox Captures:</h4>
          <div className="flex flex-wrap gap-1">
            {gameState.capturedPieces.white.map((piece, i) => (
              <span key={i} className="text-lg">
                {piece.color === 'black' ? '🐺' : '🦊'}
              </span>
            ))}
          </div>
        </div>
        <div className="bg-white p-3 rounded-xl border-3 border-black">
          <h4 className="font-bold text-bonk-orange mb-2">🐺 Wolf Captures:</h4>
          <div className="flex flex-wrap gap-1">
            {gameState.capturedPieces.black.map((piece, i) => (
              <span key={i} className="text-lg">
                {piece.color === 'white' ? '🦊' : '🐺'}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChessBoard;