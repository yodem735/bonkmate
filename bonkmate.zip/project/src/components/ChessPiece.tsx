import React from 'react';
import { ChessPiece as ChessPieceType, Position } from '../types/chess';

interface ChessPieceProps {
  piece: ChessPieceType;
  position: Position;
  onDragStart: () => void;
  isDragging: boolean;
}

const ChessPiece: React.FC<ChessPieceProps> = ({ piece, onDragStart, isDragging }) => {
  const getPieceEmoji = () => {
    const isWhite = piece.color === 'white';
    
    switch (piece.type) {
      case 'king':
        return isWhite ? '🦊👑' : '🐺👑';
      case 'queen':
        return isWhite ? '🦊💎' : '🐺💎';
      case 'rook':
        return isWhite ? '🦊🏰' : '🐺🏰';
      case 'bishop':
        return isWhite ? '🦊⛪' : '🐺⛪';
      case 'knight':
        return isWhite ? '🦊🐴' : '🐺🐴';
      case 'pawn':
        return isWhite ? '🦊' : '🐺';
      default:
        return '❓';
    }
  };

  return (
    <div
      className={`
        select-none transition-all duration-200 cursor-grab active:cursor-grabbing bonk-piece-shadow
        ${isDragging ? 'scale-125 z-50 opacity-90 animate-wiggle' : 'hover:scale-110 hover:animate-bounce-slow'}
        text-2xl
      `}
      draggable
      onDragStart={(e) => {
        e.dataTransfer.effectAllowed = 'move';
        onDragStart();
      }}
    >
      <div className="relative">
        {getPieceEmoji()}
        {isDragging && (
          <div className="absolute -top-2 -right-2 text-xs animate-spin">
            💥
          </div>
        )}
      </div>
    </div>
  );
};

export default ChessPiece;