import React, { useState } from 'react';
import { X, User, Mail, Wallet, Trophy, DollarSign, Star, Edit2, Save } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose }) => {
  const { user, updateProfile, logout, connectWallet } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [editedUsername, setEditedUsername] = useState(user?.username || '');
  const [isConnecting, setIsConnecting] = useState(false);

  if (!isOpen || !user) return null;

  const handleSave = () => {
    updateProfile({ username: editedUsername });
    setIsEditing(false);
  };

  const handleWalletUpgrade = async () => {
    setIsConnecting(true);
    try {
      await connectWallet();
      onClose();
    } catch (error) {
      console.error('Wallet connection failed:', error);
    } finally {
      setIsConnecting(false);
    }
  };

  const winRate = user.wins + user.losses > 0 
    ? ((user.wins / (user.wins + user.losses)) * 100).toFixed(1)
    : '0.0';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl border-4 border-black max-w-lg w-full bonk-glow max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="bonk-title text-2xl text-bonk-orange">Player Profile</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-bonk-light rounded-full transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          {/* Profile Info */}
          <div className="text-center mb-6">
            <div className="w-24 h-24 bg-gradient-to-br from-bonk-orange to-bonk-brown rounded-full flex items-center justify-center text-4xl border-4 border-black mx-auto mb-4">
              {user.avatar}
            </div>
            
            <div className="flex items-center justify-center space-x-2 mb-2">
              {isEditing ? (
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={editedUsername}
                    onChange={(e) => setEditedUsername(e.target.value)}
                    className="text-xl font-bold text-bonk-orange text-center border-2 border-bonk-orange rounded px-2 py-1"
                  />
                  <button
                    onClick={handleSave}
                    className="p-1 text-green-600 hover:bg-green-100 rounded"
                  >
                    <Save size={16} />
                  </button>
                </div>
              ) : (
                <>
                  <h3 className="bonk-title text-xl text-bonk-orange">{user.username}</h3>
                  <button
                    onClick={() => setIsEditing(true)}
                    className="p-1 text-bonk-brown hover:bg-bonk-light rounded"
                  >
                    <Edit2 size={16} />
                  </button>
                </>
              )}
            </div>

            <div className="flex items-center justify-center space-x-2 text-sm text-bonk-brown font-semibold">
              {user.accountType === 'email' ? (
                <>
                  <Mail size={16} />
                  <span>{user.email}</span>
                </>
              ) : (
                <>
                  <Wallet size={16} />
                  <span>{user.address?.slice(0, 8)}...{user.address?.slice(-6)}</span>
                </>
              )}
            </div>

            {/* Account Type Badge */}
            <div className={`inline-flex items-center space-x-2 px-4 py-2 rounded-full border-2 border-black mt-3 ${
              user.accountType === 'wallet' 
                ? 'bg-gradient-to-r from-purple-400 to-purple-500 text-white' 
                : 'bg-bonk-light text-bonk-brown'
            }`}>
              {user.accountType === 'wallet' ? <Wallet size={16} /> : <Mail size={16} />}
              <span className="font-bold text-sm">
                {user.accountType === 'wallet' ? 'Wallet Account' : 'Email Account'}
              </span>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-gradient-to-br from-bonk-orange to-bonk-brown p-4 rounded-xl border-3 border-black text-center text-white">
              <Star className="mx-auto mb-2" size={24} />
              <div className="bonk-title text-2xl bonk-shadow">{user.rating}</div>
              <div className="text-xs font-bold">RATING</div>
            </div>
            
            <div className="bg-gradient-to-br from-green-400 to-green-500 p-4 rounded-xl border-3 border-black text-center text-white">
              <Trophy className="mx-auto mb-2" size={24} />
              <div className="bonk-title text-2xl bonk-shadow">{winRate}%</div>
              <div className="text-xs font-bold">WIN RATE</div>
            </div>
            
            <div className="bg-gradient-to-br from-blue-400 to-blue-500 p-4 rounded-xl border-3 border-black text-center text-white">
              <DollarSign className="mx-auto mb-2" size={24} />
              <div className="bonk-title text-2xl bonk-shadow">{user.totalEarnings.toFixed(1)}</div>
              <div className="text-xs font-bold">SOL EARNED</div>
            </div>
            
            <div className="bg-gradient-to-br from-yellow-400 to-orange-500 p-4 rounded-xl border-3 border-black text-center text-white">
              <span className="text-2xl mb-2 block">🪙</span>
              <div className="bonk-title text-2xl bonk-shadow">{user.bonkTokens}</div>
              <div className="text-xs font-bold">BONK TOKENS</div>
            </div>
          </div>

          {/* Game Stats */}
          <div className="bg-bonk-light/20 p-4 rounded-xl border-2 border-bonk-orange mb-6">
            <h4 className="bonk-title text-lg text-bonk-orange mb-3">Game Statistics</h4>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-green-600">{user.wins}</div>
                <div className="text-xs text-bonk-brown font-semibold">WINS</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-red-600">{user.losses}</div>
                <div className="text-xs text-bonk-brown font-semibold">LOSSES</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-yellow-600">{user.draws}</div>
                <div className="text-xs text-bonk-brown font-semibold">DRAWS</div>
              </div>
            </div>
          </div>

          {/* Account Upgrade */}
          {user.accountType === 'email' && (
            <div className="bg-gradient-to-r from-purple-100 to-purple-200 p-4 rounded-xl border-2 border-purple-500 mb-6">
              <div className="text-center">
                <div className="text-3xl mb-2">🚀</div>
                <h4 className="bonk-title text-lg text-purple-700 mb-2">Upgrade to Wallet Account</h4>
                <p className="text-sm text-purple-600 font-semibold mb-4">
                  Connect your Solana wallet to unlock wagering and earn real SOL!
                </p>
                <button
                  onClick={handleWalletUpgrade}
                  disabled={isConnecting}
                  className="w-full flex items-center justify-center space-x-2 p-3 bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white rounded-xl font-bold border-2 border-black bonk-glow hover:scale-105 transition-all disabled:opacity-50"
                >
                  <Wallet size={18} />
                  <span className="bonk-title">
                    {isConnecting ? 'Connecting...' : 'Connect Wallet'}
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="space-y-3">
            <button
              onClick={logout}
              className="w-full p-3 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white rounded-xl font-bold border-3 border-black bonk-glow hover:scale-105 transition-all"
            >
              <span className="bonk-title">Logout</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileModal;