import { Player, GameRoom } from '../types/chess';

export const mockPlayers: Player[] = [
  {
    id: '1',
    address: 'FoxyBonker123...abc',
    username: 'BonkMaster9000',
    avatar: '🦊',
    rating: 2150,
    wins: 45,
    losses: 12,
    draws: 8,
    totalEarnings: 27.5,
    bonkTokens: 150000,
    accountType: 'wallet',
    isConnected: true
  },
  {
    id: '2',
    address: 'WolfPack456...def',
    username: 'SolanaWolf',
    avatar: '🐺',
    rating: 1980,
    wins: 38,
    losses: 18,
    draws: 6,
    totalEarnings: 18.5,
    bonkTokens: 89000,
    accountType: 'wallet',
    isConnected: true
  },
  {
    id: '3',
    email: 'foxygrandmaster@email.com',
    username: 'FoxyGrandmaster',
    avatar: '🦊',
    rating: 1875,
    wins: 32,
    losses: 22,
    draws: 4,
    totalEarnings: 0,
    bonkTokens: 67000,
    accountType: 'email',
    isConnected: true
  },
  {
    id: '4',
    address: 'BonkQueen321...jkl',
    username: 'QueenOfBonks',
    avatar: '👑',
    rating: 1750,
    wins: 28,
    losses: 25,
    draws: 7,
    totalEarnings: 9.8,
    bonkTokens: 45000,
    accountType: 'wallet',
    isConnected: true
  },
  {
    id: '5',
    email: 'solrook@email.com',
    username: 'SolanaRook',
    avatar: '🏰',
    rating: 1650,
    wins: 24,
    losses: 28,
    draws: 3,
    totalEarnings: 0,
    bonkTokens: 23000,
    accountType: 'email',
    isConnected: true
  }
];

export const mockGameRooms: GameRoom[] = [
  {
    id: 'room1',
    whitePlayer: mockPlayers[1],
    blackPlayer: null,
    wager: 1.0,
    status: 'waiting',
    createdAt: new Date().toISOString(),
    requiresWallet: true
  },
  {
    id: 'room2',
    whitePlayer: mockPlayers[2],
    blackPlayer: null,
    wager: 0,
    status: 'waiting',
    createdAt: new Date().toISOString(),
    requiresWallet: false
  },
  {
    id: 'room3',
    whitePlayer: mockPlayers[4],
    blackPlayer: null,
    wager: 0,
    status: 'waiting',
    createdAt: new Date().toISOString(),
    requiresWallet: false
  }
];

export const getCurrentPlayer = (): Player => mockPlayers[0];