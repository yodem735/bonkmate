import { ChessPiece, Position, GameState } from '../types/chess';

export const initializeBoard = (): (ChessPiece | null)[][] => {
  const board: (ChessPiece | null)[][] = Array(8).fill(null).map(() => Array(8).fill(null));
  
  // Place pawns
  for (let i = 0; i < 8; i++) {
    board[1][i] = { type: 'pawn', color: 'black', position: { x: i, y: 1 } };
    board[6][i] = { type: 'pawn', color: 'white', position: { x: i, y: 6 } };
  }
  
  // Place other pieces
  const pieceOrder: ChessPiece['type'][] = ['rook', 'knight', 'bishop', 'queen', 'king', 'bishop', 'knight', 'rook'];
  
  for (let i = 0; i < 8; i++) {
    board[0][i] = { type: pieceOrder[i], color: 'black', position: { x: i, y: 0 } };
    board[7][i] = { type: pieceOrder[i], color: 'white', position: { x: i, y: 7 } };
  }
  
  return board;
};

export const initializeGameState = (): GameState => ({
  board: initializeBoard(),
  currentPlayer: 'white',
  selectedPiece: null,
  validMoves: [],
  gameStatus: 'active',
  moveHistory: [],
  capturedPieces: { white: [], black: [] },
  kingPositions: { white: { x: 4, y: 7 }, black: { x: 4, y: 0 } },
  enPassantTarget: null,
  castlingRights: {
    whiteKingSide: true,
    whiteQueenSide: true,
    blackKingSide: true,
    blackQueenSide: true,
  },
  fiftyMoveRule: 0,
  threefoldRepetition: [],
});

export const isSquareUnderAttack = (
  position: Position,
  attackingColor: 'white' | 'black',
  board: (ChessPiece | null)[][]
): boolean => {
  for (let y = 0; y < 8; y++) {
    for (let x = 0; x < 8; x++) {
      const piece = board[y][x];
      if (piece && piece.color === attackingColor) {
        if (canPieceAttackSquare(piece, position, board)) {
          return true;
        }
      }
    }
  }
  return false;
};

const canPieceAttackSquare = (
  piece: ChessPiece,
  target: Position,
  board: (ChessPiece | null)[][]
): boolean => {
  const dx = target.x - piece.position.x;
  const dy = target.y - piece.position.y;

  switch (piece.type) {
    case 'pawn':
      const direction = piece.color === 'white' ? -1 : 1;
      return Math.abs(dx) === 1 && dy === direction;
    case 'rook':
      return (dx === 0 || dy === 0) && isPathClear(board, piece.position, target);
    case 'bishop':
      return Math.abs(dx) === Math.abs(dy) && isPathClear(board, piece.position, target);
    case 'queen':
      return ((dx === 0 || dy === 0) || (Math.abs(dx) === Math.abs(dy))) && isPathClear(board, piece.position, target);
    case 'king':
      return Math.abs(dx) <= 1 && Math.abs(dy) <= 1;
    case 'knight':
      return (Math.abs(dx) === 2 && Math.abs(dy) === 1) || (Math.abs(dx) === 1 && Math.abs(dy) === 2);
    default:
      return false;
  }
};

export const isInCheck = (
  kingColor: 'white' | 'black',
  board: (ChessPiece | null)[][],
  kingPosition: Position
): boolean => {
  const attackingColor = kingColor === 'white' ? 'black' : 'white';
  return isSquareUnderAttack(kingPosition, attackingColor, board);
};

export const isValidMove = (
  piece: ChessPiece,
  from: Position,
  to: Position,
  board: (ChessPiece | null)[][],
  gameState: GameState
): boolean => {
  if (to.x < 0 || to.x > 7 || to.y < 0 || to.y > 7) return false;
  
  const targetPiece = board[to.y][to.x];
  if (targetPiece && targetPiece.color === piece.color) return false;
  
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  
  let isValidBasicMove = false;
  
  switch (piece.type) {
    case 'pawn':
      isValidBasicMove = isValidPawnMove(piece, dx, dy, targetPiece !== null, gameState);
      break;
    case 'rook':
      isValidBasicMove = isValidRookMove(dx, dy, board, from, to);
      break;
    case 'bishop':
      isValidBasicMove = isValidBishopMove(dx, dy, board, from, to);
      break;
    case 'queen':
      isValidBasicMove = isValidQueenMove(dx, dy, board, from, to);
      break;
    case 'king':
      isValidBasicMove = isValidKingMove(dx, dy, piece, gameState, board);
      break;
    case 'knight':
      isValidBasicMove = isValidKnightMove(dx, dy);
      break;
    default:
      return false;
  }
  
  if (!isValidBasicMove) return false;
  
  // Check if move would leave king in check
  const testBoard = board.map(row => [...row]);
  testBoard[to.y][to.x] = { ...piece, position: to };
  testBoard[from.y][from.x] = null;
  
  const kingPos = piece.type === 'king' ? to : gameState.kingPositions[piece.color];
  
  return !isInCheck(piece.color, testBoard, kingPos);
};

const isValidPawnMove = (
  piece: ChessPiece,
  dx: number,
  dy: number,
  isCapture: boolean,
  gameState: GameState
): boolean => {
  const direction = piece.color === 'white' ? -1 : 1;
  const startRow = piece.color === 'white' ? 6 : 1;
  
  // Forward move
  if (dx === 0 && !isCapture) {
    if (dy === direction) return true;
    if (piece.position.y === startRow && dy === 2 * direction) return true;
  }
  
  // Capture move
  if (Math.abs(dx) === 1 && dy === direction) {
    if (isCapture) return true;
    
    // En passant
    if (gameState.enPassantTarget && 
        gameState.enPassantTarget.x === piece.position.x + dx &&
        gameState.enPassantTarget.y === piece.position.y + dy) {
      return true;
    }
  }
  
  return false;
};

const isValidRookMove = (dx: number, dy: number, board: (ChessPiece | null)[][], from: Position, to: Position): boolean => {
  if (dx !== 0 && dy !== 0) return false;
  return isPathClear(board, from, to);
};

const isValidBishopMove = (dx: number, dy: number, board: (ChessPiece | null)[][], from: Position, to: Position): boolean => {
  if (Math.abs(dx) !== Math.abs(dy)) return false;
  return isPathClear(board, from, to);
};

const isValidQueenMove = (dx: number, dy: number, board: (ChessPiece | null)[][], from: Position, to: Position): boolean => {
  return isValidRookMove(dx, dy, board, from, to) || isValidBishopMove(dx, dy, board, from, to);
};

const isValidKingMove = (
  dx: number,
  dy: number,
  piece: ChessPiece,
  gameState: GameState,
  board: (ChessPiece | null)[][]
): boolean => {
  // Normal king move
  if (Math.abs(dx) <= 1 && Math.abs(dy) <= 1) return true;
  
  // Castling
  if (dy === 0 && Math.abs(dx) === 2 && !piece.hasMoved) {
    const isKingSide = dx > 0;
    const castlingRights = piece.color === 'white' 
      ? (isKingSide ? gameState.castlingRights.whiteKingSide : gameState.castlingRights.whiteQueenSide)
      : (isKingSide ? gameState.castlingRights.blackKingSide : gameState.castlingRights.blackQueenSide);
    
    if (!castlingRights) return false;
    
    // Check if path is clear and not under attack
    const rookX = isKingSide ? 7 : 0;
    const rook = board[piece.position.y][rookX];
    
    if (!rook || rook.type !== 'rook' || rook.hasMoved) return false;
    
    // Check squares between king and rook
    const startX = Math.min(piece.position.x, rookX);
    const endX = Math.max(piece.position.x, rookX);
    
    for (let x = startX + 1; x < endX; x++) {
      if (board[piece.position.y][x] !== null) return false;
    }
    
    // Check if king passes through attacked squares
    const step = isKingSide ? 1 : -1;
    for (let i = 0; i <= 2; i++) {
      const checkX = piece.position.x + (i * step);
      if (isSquareUnderAttack({ x: checkX, y: piece.position.y }, piece.color === 'white' ? 'black' : 'white', board)) {
        return false;
      }
    }
    
    return true;
  }
  
  return false;
};

const isValidKnightMove = (dx: number, dy: number): boolean => {
  return (Math.abs(dx) === 2 && Math.abs(dy) === 1) || (Math.abs(dx) === 1 && Math.abs(dy) === 2);
};

const isPathClear = (board: (ChessPiece | null)[][], from: Position, to: Position): boolean => {
  const dx = Math.sign(to.x - from.x);
  const dy = Math.sign(to.y - from.y);
  
  let x = from.x + dx;
  let y = from.y + dy;
  
  while (x !== to.x || y !== to.y) {
    if (board[y][x] !== null) return false;
    x += dx;
    y += dy;
  }
  
  return true;
};

export const getPossibleMoves = (piece: ChessPiece, gameState: GameState): Position[] => {
  const moves: Position[] = [];
  
  for (let y = 0; y < 8; y++) {
    for (let x = 0; x < 8; x++) {
      if (isValidMove(piece, piece.position, { x, y }, gameState.board, gameState)) {
        moves.push({ x, y });
      }
    }
  }
  
  return moves;
};

export const isCheckmate = (gameState: GameState): boolean => {
  const currentColor = gameState.currentPlayer;
  const kingPos = gameState.kingPositions[currentColor];
  
  // Must be in check to be checkmate
  if (!isInCheck(currentColor, gameState.board, kingPos)) return false;
  
  // Check if any piece can make a legal move
  for (let y = 0; y < 8; y++) {
    for (let x = 0; x < 8; x++) {
      const piece = gameState.board[y][x];
      if (piece && piece.color === currentColor) {
        const possibleMoves = getPossibleMoves(piece, gameState);
        if (possibleMoves.length > 0) return false;
      }
    }
  }
  
  return true;
};

export const isStalemate = (gameState: GameState): boolean => {
  const currentColor = gameState.currentPlayer;
  const kingPos = gameState.kingPositions[currentColor];
  
  // Must not be in check to be stalemate
  if (isInCheck(currentColor, gameState.board, kingPos)) return false;
  
  // Check if any piece can make a legal move
  for (let y = 0; y < 8; y++) {
    for (let x = 0; x < 8; x++) {
      const piece = gameState.board[y][x];
      if (piece && piece.color === currentColor) {
        const possibleMoves = getPossibleMoves(piece, gameState);
        if (possibleMoves.length > 0) return false;
      }
    }
  }
  
  return true;
};

export const getBoardHash = (gameState: GameState): string => {
  let hash = '';
  for (let y = 0; y < 8; y++) {
    for (let x = 0; x < 8; x++) {
      const piece = gameState.board[y][x];
      if (piece) {
        hash += `${piece.type}${piece.color}${x}${y}`;
      } else {
        hash += 'empty';
      }
    }
  }
  hash += gameState.currentPlayer;
  hash += JSON.stringify(gameState.castlingRights);
  hash += gameState.enPassantTarget ? `${gameState.enPassantTarget.x}${gameState.enPassantTarget.y}` : 'none';
  return hash;
};