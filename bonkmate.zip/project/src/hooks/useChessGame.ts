import { useState, useCallback } from 'react';
import { GameState, Position, ChessPiece } from '../types/chess';
import { 
  initializeGameState, 
  getPossibleMoves, 
  isValidMove, 
  isCheckmate, 
  isStalemate, 
  isInCheck,
  getBoardHash
} from '../utils/chessLogic';

export const useChessGame = () => {
  const [gameState, setGameState] = useState<GameState>(initializeGameState());
  const [timeLeft, setTimeLeft] = useState({ white: 600, black: 600 });

  const selectPiece = useCallback((position: Position | null) => {
    if (!position) {
      setGameState(prev => ({
        ...prev,
        selectedPiece: null,
        validMoves: []
      }));
      return;
    }

    const piece = gameState.board[position.y][position.x];
    if (!piece || piece.color !== gameState.currentPlayer) {
      setGameState(prev => ({
        ...prev,
        selectedPiece: null,
        validMoves: []
      }));
      return;
    }

    const validMoves = getPossibleMoves(piece, gameState);
    setGameState(prev => ({
      ...prev,
      selectedPiece: position,
      validMoves
    }));
  }, [gameState]);

  const makeMove = useCallback((from: Position, to: Position) => {
    const piece = gameState.board[from.y][from.x];
    if (!piece || !isValidMove(piece, from, to, gameState.board, gameState)) return;

    const newBoard = gameState.board.map(row => [...row]);
    const capturedPiece = newBoard[to.y][to.x];
    
    // Handle captures
    const newCapturedPieces = { ...gameState.capturedPieces };
    if (capturedPiece) {
      if (piece.color === 'white') {
        newCapturedPieces.white.push(capturedPiece);
      } else {
        newCapturedPieces.black.push(capturedPiece);
      }
    }

    // Handle en passant capture
    let enPassantCapture = false;
    if (piece.type === 'pawn' && gameState.enPassantTarget && 
        to.x === gameState.enPassantTarget.x && to.y === gameState.enPassantTarget.y) {
      const capturedPawnY = piece.color === 'white' ? to.y + 1 : to.y - 1;
      const capturedPawn = newBoard[capturedPawnY][to.x];
      if (capturedPawn) {
        newBoard[capturedPawnY][to.x] = null;
        if (piece.color === 'white') {
          newCapturedPieces.white.push(capturedPawn);
        } else {
          newCapturedPieces.black.push(capturedPawn);
        }
        enPassantCapture = true;
      }
    }

    // Handle castling
    let castlingMove = false;
    if (piece.type === 'king' && Math.abs(to.x - from.x) === 2) {
      castlingMove = true;
      const isKingSide = to.x > from.x;
      const rookFromX = isKingSide ? 7 : 0;
      const rookToX = isKingSide ? 5 : 3;
      const rook = newBoard[from.y][rookFromX];
      
      if (rook) {
        newBoard[from.y][rookToX] = { ...rook, position: { x: rookToX, y: from.y }, hasMoved: true };
        newBoard[from.y][rookFromX] = null;
      }
    }

    // Make the move
    const movedPiece = { ...piece, position: to, hasMoved: true };
    newBoard[to.y][to.x] = movedPiece;
    newBoard[from.y][from.x] = null;

    // Update king positions
    const newKingPositions = { ...gameState.kingPositions };
    if (piece.type === 'king') {
      newKingPositions[piece.color] = to;
    }

    // Update castling rights
    const newCastlingRights = { ...gameState.castlingRights };
    if (piece.type === 'king') {
      if (piece.color === 'white') {
        newCastlingRights.whiteKingSide = false;
        newCastlingRights.whiteQueenSide = false;
      } else {
        newCastlingRights.blackKingSide = false;
        newCastlingRights.blackQueenSide = false;
      }
    } else if (piece.type === 'rook') {
      if (piece.color === 'white') {
        if (from.x === 0) newCastlingRights.whiteQueenSide = false;
        if (from.x === 7) newCastlingRights.whiteKingSide = false;
      } else {
        if (from.x === 0) newCastlingRights.blackQueenSide = false;
        if (from.x === 7) newCastlingRights.blackKingSide = false;
      }
    }

    // Set en passant target
    let newEnPassantTarget: Position | null = null;
    if (piece.type === 'pawn' && Math.abs(to.y - from.y) === 2) {
      newEnPassantTarget = { x: to.x, y: (from.y + to.y) / 2 };
    }

    // Update fifty move rule
    const newFiftyMoveRule = (piece.type === 'pawn' || capturedPiece || enPassantCapture) 
      ? 0 
      : gameState.fiftyMoveRule + 1;

    // Generate move notation
    const moveNotation = generateMoveNotation(piece, from, to, capturedPiece !== null || enPassantCapture, castlingMove);

    const nextPlayer = gameState.currentPlayer === 'white' ? 'black' : 'white';
    
    const newGameState: GameState = {
      board: newBoard,
      currentPlayer: nextPlayer,
      selectedPiece: null,
      validMoves: [],
      gameStatus: 'active',
      moveHistory: [...gameState.moveHistory, moveNotation],
      capturedPieces: newCapturedPieces,
      kingPositions: newKingPositions,
      enPassantTarget: newEnPassantTarget,
      castlingRights: newCastlingRights,
      fiftyMoveRule: newFiftyMoveRule,
      threefoldRepetition: [...gameState.threefoldRepetition, getBoardHash(gameState)]
    };

    // Check for game end conditions
    if (isCheckmate(newGameState)) {
      newGameState.gameStatus = 'checkmate';
    } else if (isStalemate(newGameState)) {
      newGameState.gameStatus = 'stalemate';
    } else if (isInCheck(nextPlayer, newBoard, newKingPositions[nextPlayer])) {
      newGameState.gameStatus = 'check';
    } else if (newFiftyMoveRule >= 50) {
      newGameState.gameStatus = 'draw';
    } else {
      // Check for threefold repetition
      const currentHash = getBoardHash(newGameState);
      const repetitions = newGameState.threefoldRepetition.filter(hash => hash === currentHash).length;
      if (repetitions >= 2) {
        newGameState.gameStatus = 'draw';
      }
    }

    setGameState(newGameState);
  }, [gameState]);

  const generateMoveNotation = (
    piece: ChessPiece,
    from: Position,
    to: Position,
    isCapture: boolean,
    isCastling: boolean
  ): string => {
    if (isCastling) {
      return to.x > from.x ? 'O-O' : 'O-O-O';
    }

    const pieceSymbol = piece.type === 'pawn' ? '' : piece.type.charAt(0).toUpperCase();
    const fromSquare = `${String.fromCharCode(97 + from.x)}${8 - from.y}`;
    const toSquare = `${String.fromCharCode(97 + to.x)}${8 - to.y}`;
    const captureSymbol = isCapture ? 'x' : '';

    if (piece.type === 'pawn' && isCapture) {
      return `${String.fromCharCode(97 + from.x)}${captureSymbol}${toSquare}`;
    }

    return `${pieceSymbol}${captureSymbol}${toSquare}`;
  };

  const resetGame = useCallback(() => {
    setGameState(initializeGameState());
    setTimeLeft({ white: 600, black: 600 });
  }, []);

  return {
    gameState,
    timeLeft,
    selectPiece,
    makeMove,
    resetGame
  };
};