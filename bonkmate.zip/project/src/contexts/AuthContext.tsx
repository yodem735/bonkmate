import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { AuthState, Player } from '../types/chess';

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<boolean>;
  register: (email: string, password: string, username: string) => Promise<boolean>;
  connectWallet: () => Promise<boolean>;
  logout: () => void;
  updateProfile: (updates: Partial<Player>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    user: null,
    accountType: null,
  });

  useEffect(() => {
    // Check for existing session
    const savedUser = localStorage.getItem('bonk_chess_user');
    if (savedUser) {
      const user = JSON.parse(savedUser);
      setAuthState({
        isAuthenticated: true,
        user,
        accountType: user.accountType,
      });
    }
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Mock user data - in real app, this would come from your backend
      const user: Player = {
        id: `email_${Date.now()}`,
        email,
        username: email.split('@')[0],
        avatar: '🦊',
        rating: 1200,
        wins: 0,
        losses: 0,
        draws: 0,
        totalEarnings: 0,
        bonkTokens: 1000,
        accountType: 'email',
        isConnected: true,
      };

      localStorage.setItem('bonk_chess_user', JSON.stringify(user));
      setAuthState({
        isAuthenticated: true,
        user,
        accountType: 'email',
      });

      return true;
    } catch (error) {
      console.error('Login failed:', error);
      return false;
    }
  };

  const register = async (email: string, password: string, username: string): Promise<boolean> => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const user: Player = {
        id: `email_${Date.now()}`,
        email,
        username,
        avatar: '🦊',
        rating: 1200,
        wins: 0,
        losses: 0,
        draws: 0,
        totalEarnings: 0,
        bonkTokens: 1000,
        accountType: 'email',
        isConnected: true,
      };

      localStorage.setItem('bonk_chess_user', JSON.stringify(user));
      setAuthState({
        isAuthenticated: true,
        user,
        accountType: 'email',
      });

      return true;
    } catch (error) {
      console.error('Registration failed:', error);
      return false;
    }
  };

  const connectWallet = async (): Promise<boolean> => {
    try {
      // Simulate wallet connection
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const mockAddress = 'FoxyBonker' + Math.random().toString(36).substring(2, 15);
      const user: Player = {
        id: `wallet_${Date.now()}`,
        address: mockAddress,
        username: `${mockAddress.slice(0, 8)}...`,
        avatar: '🦊',
        rating: 1500,
        wins: 5,
        losses: 2,
        draws: 1,
        totalEarnings: 2.5,
        bonkTokens: 50000,
        accountType: 'wallet',
        isConnected: true,
      };

      localStorage.setItem('bonk_chess_user', JSON.stringify(user));
      setAuthState({
        isAuthenticated: true,
        user,
        accountType: 'wallet',
      });

      return true;
    } catch (error) {
      console.error('Wallet connection failed:', error);
      return false;
    }
  };

  const logout = () => {
    localStorage.removeItem('bonk_chess_user');
    setAuthState({
      isAuthenticated: false,
      user: null,
      accountType: null,
    });
  };

  const updateProfile = (updates: Partial<Player>) => {
    if (authState.user) {
      const updatedUser = { ...authState.user, ...updates };
      localStorage.setItem('bonk_chess_user', JSON.stringify(updatedUser));
      setAuthState(prev => ({
        ...prev,
        user: updatedUser,
      }));
    }
  };

  return (
    <AuthContext.Provider
      value={{
        ...authState,
        login,
        register,
        connectWallet,
        logout,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};