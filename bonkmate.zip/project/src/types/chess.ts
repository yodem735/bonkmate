export interface Position {
  x: number;
  y: number;
}

export interface ChessPiece {
  type: 'king' | 'queen' | 'rook' | 'bishop' | 'knight' | 'pawn';
  color: 'white' | 'black';
  position: Position;
  hasMoved?: boolean;
}

export interface GameState {
  board: (ChessPiece | null)[][];
  currentPlayer: 'white' | 'black';
  selectedPiece: Position | null;
  validMoves: Position[];
  gameStatus: 'active' | 'check' | 'checkmate' | 'stalemate' | 'draw';
  moveHistory: string[];
  capturedPieces: { white: ChessPiece[]; black: ChessPiece[] };
  kingPositions: { white: Position; black: Position };
  enPassantTarget: Position | null;
  castlingRights: {
    whiteKingSide: boolean;
    whiteQueenSide: boolean;
    blackKingSide: boolean;
    blackQueenSide: boolean;
  };
  fiftyMoveRule: number;
  threefoldRepetition: string[];
}

export interface Player {
  id: string;
  address?: string;
  email?: string;
  username: string;
  avatar: string;
  rating: number;
  wins: number;
  losses: number;
  draws: number;
  totalEarnings: number;
  bonkTokens: number;
  accountType: 'email' | 'wallet';
  isConnected: boolean;
}

export interface GameRoom {
  id: string;
  whitePlayer: Player;
  blackPlayer: Player | null;
  wager: number;
  status: 'waiting' | 'active' | 'completed';
  createdAt: string;
  requiresWallet: boolean;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: Player | null;
  accountType: 'email' | 'wallet' | null;
}