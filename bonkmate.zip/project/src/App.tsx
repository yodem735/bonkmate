import React, { useState } from 'react';
import Header from './components/Header';
import ChessBoard from './components/ChessBoard';
import GameInfo from './components/GameInfo';
import WagerSystem from './components/WagerSystem';
import Leaderboard from './components/Leaderboard';
import { useChessGame } from './hooks/useChessGame';
import { useAuth } from './contexts/AuthContext';
import { mockPlayers, mockGameRooms } from './data/mockData';
import { GameRoom } from './types/chess';
import { AuthProvider } from './contexts/AuthContext';

function AppContent() {
  const [currentView, setCurrentView] = useState<'game' | 'wager' | 'leaderboard'>('wager');
  const [availableGames, setAvailableGames] = useState<GameRoom[]>(mockGameRooms);
  const [currentGame, setCurrentGame] = useState<GameRoom | null>(null);
  const { gameState, timeLeft, selectPiece, makeMove, resetGame } = useChessGame();
  const { user, isAuthenticated } = useAuth();

  const handleCreateGame = (wager: number) => {
    if (!user) return;
    
    const newGame: GameRoom = {
      id: `room_${Date.now()}`,
      whitePlayer: user,
      blackPlayer: null,
      wager,
      status: 'waiting',
      createdAt: new Date().toISOString(),
      requiresWallet: wager > 0
    };
    
    setAvailableGames(prev => [...prev, newGame]);
    setCurrentGame(newGame);
  };

  const handleJoinGame = (gameId: string) => {
    if (!user) return;
    
    const game = availableGames.find(g => g.id === gameId);
    if (game) {
      const updatedGame = {
        ...game,
        blackPlayer: user,
        status: 'active' as const
      };
      
      setAvailableGames(prev => prev.filter(g => g.id !== gameId));
      setCurrentGame(updatedGame);
      setCurrentView('game');
      resetGame();
    }
  };

  const renderContent = () => {
    switch (currentView) {
      case 'game':
        if (!currentGame || !currentGame.blackPlayer) {
          return (
            <div className="flex items-center justify-center min-h-96">
              <div className="text-center bg-white p-12 rounded-2xl border-4 border-black bonk-glow">
                <div className="text-8xl mb-4">😴</div>
                <p className="bonk-title text-2xl text-bonk-orange mb-2">No BONK Battle Active!</p>
                <p className="text-bonk-brown font-semibold mb-6">Create or join a battle to start bonking!</p>
                <button
                  onClick={() => setCurrentView('wager')}
                  className="px-8 py-4 bg-gradient-to-r from-bonk-orange to-bonk-brown hover:from-bonk-brown hover:to-bonk-orange text-white rounded-xl transition-all duration-200 font-bold border-3 border-black bonk-glow hover:scale-105"
                >
                  <span className="bonk-title text-xl">FIND BONK BATTLE! 🏏</span>
                </button>
              </div>
            </div>
          );
        }
        
        return (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            <div className="lg:col-span-3 flex justify-center">
              <ChessBoard
                gameState={gameState}
                onMove={makeMove}
                onPieceSelect={selectPiece}
              />
            </div>
            <div className="lg:col-span-1">
              <GameInfo
                gameState={gameState}
                whitePlayer={currentGame.whitePlayer}
                blackPlayer={currentGame.blackPlayer}
                wager={currentGame.wager}
                timeLeft={timeLeft}
              />
            </div>
          </div>
        );
        
      case 'wager':
        return (
          <WagerSystem
            onCreateGame={handleCreateGame}
            onJoinGame={handleJoinGame}
            availableGames={availableGames}
            currentPlayer={user || mockPlayers[0]}
          />
        );
        
      case 'leaderboard':
        return <Leaderboard players={mockPlayers} />;
        
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-bonk-light via-white to-bonk-light">
      <Header currentView={currentView} onViewChange={setCurrentView} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderContent()}
      </main>
      
      {/* Background decoration */}
      <div className="fixed inset-0 pointer-events-none opacity-5">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-bonk-orange rounded-full filter blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-bonk-brown rounded-full filter blur-3xl animate-pulse"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-9xl opacity-10">
          🦊🏏
        </div>
      </div>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;